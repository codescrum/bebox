#
#   irb/version.rb - irb version definition file
#   	$Release Version: 0.9.5$
#   	$Revision: 11708 $
#   	$Date: 2007-02-13 08:01:19 +0900 (Tue, 13 Feb 2007) $
#   	by Keiju ISHITSUKA(keiju@ishitsuka.com)
#
# --
#
#   
#

module IRB
  @RELEASE_VERSION = "0.9.5"
  @LAST_UPDATE_DATE = "05/04/13"
end
